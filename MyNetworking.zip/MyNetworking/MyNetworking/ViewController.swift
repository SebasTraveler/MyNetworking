//
//  ViewController.swift
//  MyNetworking
//
//  Created by Sebastian  Reyes on 11/07/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        nameLabel.text = ""
        emailLabel.text = ""
        
        activityIndicator.hidesWhenStopped = true
        activityIndicator.stopAnimating()
    }

    @IBAction func getUserAction(_ sender: Any) {
        
        activityIndicator.startAnimating()
        
        NetworkingProvider.shared.getUser(id: 24) { (user) in
            
            self.activityIndicator.stopAnimating()
            
            self.nameLabel.text = user.name
            self.emailLabel.text = user.email
            
            
        } failure: { (error) in
            
            self.activityIndicator.stopAnimating()
            
            self.nameLabel.text = error.debugDescription
            print(error.debugDescription)
        }
    }
}


