//
//  NetworkinProvide.swift
//  MyNetworking
//
//  Created by Sebastian  Reyes on 11/07/22.
//

import Foundation
import Alamofire

final class NetworkingProvider {
    
    static let shared = NetworkingProvider()
    
    private let kBaseUrl = "https://gorest.co.in/public/v2/"
    private let kStatusOk = 200...299
    
    func getUser(id: Int, success: @escaping (_ user: UserResponse) -> (), failure: @escaping (_ error: Error?) -> ()) {
        
         let url = "\(kBaseUrl)users/\(id)"
        
        AF.request(url, method: .get).validate(statusCode: kStatusOk).responseDecodable (of: UserResponse.self) {
            response in
            
            if let user = response.value {
               success(user)
            } else {
                failure(response.error)
            }
            
        }
    }

}
