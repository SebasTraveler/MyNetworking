//
//  User.swift
//  MyNetworking
//
//  Created by Sebastian  Reyes on 11/07/22.
//

import Foundation
import Alamofire

struct UserResponse: Decodable {

    let id: Int?
    let name: String?
    let email: String?
    let gender: String?
    let status: String?
}


/*
 "id": 1,
    "name": "Kin Nambeesan",
    "email": "kin_nambeesan@dooley.info",
    "gender": "female",
    "status": "inactive"
 */
